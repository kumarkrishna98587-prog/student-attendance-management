# Student Attendance Management System

A diploma-level web application made with Python, Flask, SQLite, HTML, and CSS.

## Features
- Admin login and password change
- Dashboard summary
- Add, search, and delete students
- Mark attendance by date (Present, Absent, Leave)
- Student-wise attendance percentage reports
- Export report to CSV for Excel
- SQLite database is created automatically

## Requirements
- Python 3.10 or newer recommended
- Visual Studio Code
- Internet connection only to install Flask (the app itself runs locally)

## Run in VS Code (Windows)
1. Extract this ZIP file.
2. Open the `student_attendance_management_system` folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   ```powershell
   py -m venv .venv
   ```
5. Activate it:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, you can use Command Prompt and run:
   ```bat
   .venv\Scripts\activate.bat
   ```
6. Install dependencies:
   ```powershell
   python -m pip install -r requirements.txt
   ```
7. Start the server:
   ```powershell
   python app.py
   ```
8. Open this address in your browser:
   `http://127.0.0.1:5000`

## First login
- Username: `admin`
- Password: `admin12345`

Immediately change the default password using the Password menu. Do not deploy this development version publicly without changing the secret key, disabling debug mode, and applying production security settings.

## How to use
1. Log in.
2. Open Students and add students with unique roll numbers.
3. Open Attendance, select a date, choose Present / Absent / Leave, then Save Attendance.
4. Open Reports to see percentages and export a CSV report.

## Attendance calculation
Attendance % = Present records / all marked attendance records × 100.
Only dates that have a saved status are included.

## Database
`attendance.db` is created automatically in the project folder when `app.py` starts. Keep a backup of this file to preserve records.

## Troubleshooting
- `No module named flask`: activate `.venv`, then run `python -m pip install -r requirements.txt`.
- `py is not recognized`: try `python -m venv .venv` instead of `py -m venv .venv`.
- Port 5000 already in use: close the other app using it, or change the final line in `app.py` to `app.run(debug=True, port=5001)` and open `http://127.0.0.1:5001`.
